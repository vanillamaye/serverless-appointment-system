// Import MySQL (async/await) and AWS SDK DynamoDB client
import mysql from 'mysql2/promise';
import {
  DynamoDBClient,
  BatchGetItemCommand,
  QueryCommand,
  TransactWriteItemsCommand
} from "@aws-sdk/client-dynamodb";

// Initialize DynamoDB client
const dynamo = new DynamoDBClient({ region: process.env.REGION });

/*
  AWS Lambda main handler
  Routes requests based on HTTP method + path
*/
export const handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  const method = event.requestContext.http.method;
  const path = event.requestContext.http.path;
  const pathParams = event.pathParameters || {};
  const queryParams = event.queryStringParameters || {};
  const body = event.body ? JSON.parse(event.body) : {};

  // CORS preflight
  if (method === 'OPTIONS') {
    return corsResponse();
  }

  const conn = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
  });

  try {

    /*
      ===============================
      ROUTE: GET /services
      ===============================
      Retrieve all available services
    */
    if (method === "GET" && path === "/services") {
      const [rows] = await conn.execute(`
        SELECT service_id, title, description, duration_min, created_at
        FROM services
        ORDER BY created_at DESC
      `);
      return json(rows);
    }

    /*
      ===============================
      ROUTE: GET /service/{service_id}
      ===============================
      Fetch single service details
    */
    if (method === "GET" && path.startsWith("/service/")) {
      const serviceId = pathParams.service_id;

      const [rows] = await conn.execute(
        "SELECT * FROM services WHERE service_id = ?",
        [serviceId]
      );

      if (rows.length === 0) {
        return json({ message: "Service not found" }, 404);
      }

      return json(rows[0]);
    }

    /*
      ===============================
      ROUTE: POST /appointments
      ===============================
      Client requests an appointment
    */
    if (method === "POST" && path === "/appointments") {
      const {
        appointment_id,
        user_id,
        service_id,
        appointment_date,
        appointment_time
      } = body;

      if (!appointment_id || !user_id || !service_id || !appointment_date || !appointment_time) {
        return json({ message: "Missing required fields" }, 400);
      }

      await conn.execute(`
        INSERT INTO appointments
        (appointment_id, user_id, service_id, appointment_date, appointment_time, status)
        VALUES (?, ?, ?, ?, ?, 'pending')
      `, [
        appointment_id,
        user_id,
        service_id,
        appointment_date,
        appointment_time
      ]);

      return json({ message: "Appointment request submitted" }, 201);
    }

    /*
      ===============================
      ROUTE: GET /appointments/{user_id}
      ===============================
      View client appointments
    */
    if (method === "GET" && path.startsWith("/appointments/")) {
      const userId = pathParams.user_id;

      const [rows] = await conn.execute(`
        SELECT a.appointment_id, s.title AS service,
               a.appointment_date, a.appointment_time, a.status
        FROM appointments a
        JOIN services s ON a.service_id = s.service_id
        WHERE a.user_id = ?
        ORDER BY a.appointment_date ASC
      `, [userId]);

      return json(rows);
    }

    /*
      ===============================
      ROUTE: PUT /appointments/{appointment_id}
      ===============================
      Admin approves / cancels appointment
    */
    if (method === "PUT" && path.startsWith("/appointments/")) {
      const appointmentId = pathParams.appointment_id;
      const { status } = body;

      if (!['approved', 'cancelled'].includes(status)) {
        return json({ message: "Invalid status" }, 400);
      }

      await conn.execute(
        "UPDATE appointments SET status = ? WHERE appointment_id = ?",
        [status, appointmentId]
      );

      return json({ message: "Appointment updated" });
    }

    return json({ message: "Route not found" }, 404);

  } catch (err) {
    console.error(err);
    return json({ error: err.message }, 500);
  } finally {
    await conn.end();
  }
};

// Helper responses
function json(data, statusCode = 200) {
  return {
    statusCode,
    headers: corsHeaders(),
    body: JSON.stringify(data),
  };
}

function corsResponse() {
  return {
    statusCode: 200,
    headers: corsHeaders(),
    body: ''
  };
}

function corsHeaders() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Requested-With",
    "Access-Control-Allow-Credentials": true
  };
}
